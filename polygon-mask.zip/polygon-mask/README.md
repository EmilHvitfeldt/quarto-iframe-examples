# tsParticles Polygon Mask

A Pen created on CodePen.io. Original URL: [https://codepen.io/matteobruni/pen/yLNpgKW](https://codepen.io/matteobruni/pen/yLNpgKW).

- removed github links from html
