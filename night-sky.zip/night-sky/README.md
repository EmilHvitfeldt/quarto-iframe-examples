A Pen created on CodePen.io. Original URL: [https://codepen.io/WebSonick/pen/nBPZZO](https://codepen.io/WebSonick/pen/nBPZZO).

