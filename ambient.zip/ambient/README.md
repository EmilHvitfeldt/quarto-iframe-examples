# Grayscale Ambient Background

A Pen created on CodePen.io. Original URL: [https://codepen.io/jencrosby/pen/NWxZOyX](https://codepen.io/jencrosby/pen/NWxZOyX).

Particle background 

This is being left unmodified.
