# Metaballs - WebGL

A Pen created on CodePen.io. Original URL: [https://codepen.io/TC5550/pen/WNNWoaO](https://codepen.io/TC5550/pen/WNNWoaO).

- Removed title

Color is generated as `gl_FragColor`. Modify formula to get different colors.
