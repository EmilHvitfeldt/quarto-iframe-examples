# A week in motion #8.1

A Pen created on CodePen.io. Original URL: [https://codepen.io/trajektorijus/pen/mdeBYrX](https://codepen.io/trajektorijus/pen/mdeBYrX).

- removed FPS display
- moved colors to global option
