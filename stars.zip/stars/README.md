A Pen created on CodePen.io. Original URL: [https://codepen.io/johnbgarcia/pen/qqdgGp](https://codepen.io/johnbgarcia/pen/qqdgGp).

