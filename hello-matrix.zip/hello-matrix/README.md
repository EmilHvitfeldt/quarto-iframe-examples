A Pen created on CodePen.io. Original URL: [https://codepen.io/MananTank/pen/rNVQKPR](https://codepen.io/MananTank/pen/rNVQKPR).

Everything is controlled in `script.js`. You can change the text by modifying `langs`.

- Modified speed to be quite a bit slower, set global options
- added global options to control colors
