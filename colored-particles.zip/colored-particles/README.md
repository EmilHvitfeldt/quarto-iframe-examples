# tsParticles - Slack Colored Particles

A Pen created on CodePen.io. Original URL: [https://codepen.io/matteobruni/pen/ZExLYyg](https://codepen.io/matteobruni/pen/ZExLYyg).

- removed github buttons
