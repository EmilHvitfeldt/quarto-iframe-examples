# Grid Worms

A Pen created on CodePen.io. Original URL: [https://codepen.io/redutron/pen/MWajjbQ](https://codepen.io/redutron/pen/MWajjbQ).

Animates connected nodes about a grid