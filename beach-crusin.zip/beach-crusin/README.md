# Beach Crusin' 🏖️

A Pen created on CodePen.io. Original URL: [https://codepen.io/a-trost/pen/VwLYJpR](https://codepen.io/a-trost/pen/VwLYJpR).

Drawn in Illustrator, created with SVG and GSAP.